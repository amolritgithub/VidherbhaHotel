package com.vidherbhahotel.VidherbhaHotel.Dao;


import java.sql.Connection;
  
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mysql.jdbc.PreparedStatement;
import com.vidherbhahotel.VidherbhaHotel.Menu.Menu;
import com.vidherbhahotel.VidherbhaHotel.Utility.Utility;

@RestController
public class Dao {
	
	
	static ArrayList<Menu> menu1 = new ArrayList<Menu>();
	@RequestMapping("selectmenudao")
	public static ArrayList<Menu> fetchedmenu() throws Exception {
		Utility utility = new Utility();
		Connection con = utility.getCon();

		String sql = "select * from hotelmenu";
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(sql);
		while (rs.next()) {
			long id = rs.getLong(1);
			String name = rs.getString(2);
			long price = rs.getLong(3);
			String description = rs.getString(4);
			Menu mn = new Menu(id, name, price, description);
			menu1.add(mn);
		}
		System.out.println(menu1);
		return menu1;
	}

	@GetMapping("selectgetmenudao")
	public ArrayList<Menu> fetchmenu() throws Exception {
		Utility utility = new Utility();
		Connection con = utility.getCon();

		String sql = "select * from hotelmenu";
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(sql);
		while (rs.next()) {
			long id = rs.getLong(1);
			String name = rs.getString(2);
			long price = rs.getLong(3); 
			String description = rs.getString(4);
			Menu mn = new Menu(id, name, price, description);
			menu1.add(mn);
		}
		System.out.println(menu1);
		return menu1;
	}

	@PostMapping("insertmenudetile")
	public String addStudentDetile(@RequestBody Menu menu) throws Exception {
		System.out.println(menu);
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/item", "root", "root");
		String sql = "insert into hotelmenu(id,name,price,description) values(?,?,?,?)";
		java.sql.PreparedStatement ps = connection.prepareStatement(sql);
		ps.setLong(1, menu.getId());
		ps.setString(2, menu.getName());
		ps.setLong(3, menu.getPrice());
		ps.setString(4, menu.getDescription());
		int nn =ps.executeUpdate();
		System.out.println(nn);
		menu1.add(menu);
		return "insert menu Succesfully";
	}

	@PutMapping("updateMenudetile")
	public String updateStudentDetile(long price, int id) throws Exception {

		System.out.println(menu1);
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/item", "root", "root");
		String sql = "update hotelmenu set price= " + price + " where id = " + id + "";
		PreparedStatement ps = (PreparedStatement) connection.prepareStatement(sql);
		int rs = ps.executeUpdate(sql);
		System.err.println(rs);
		if (rs > 0) {
			return " Update Menu SuccessFully";
		} else {
			return "Something Went Wrong";
		}

	}

	@DeleteMapping("deleteMenudetile")
	public String deleteStudentDetile() throws Exception {

		System.out.println(menu1);
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/item", "root", "root");
		String sql = "delete from hotelmenu where id=77";
		Statement statement = connection.createStatement();
		int i = statement.executeUpdate(sql);
		System.err.println(i);
		if (i > 0) {
			return "delete Successfully";
		} 
		else {
			return "delete not Successfully";
		}
	}

}
