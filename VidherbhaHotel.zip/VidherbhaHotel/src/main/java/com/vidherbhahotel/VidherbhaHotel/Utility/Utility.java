package com.vidherbhahotel.VidherbhaHotel.Utility;

import java.sql.Connection;
 
import java.sql.DriverManager;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class Utility {
	private Connection cn ;
	
	public Utility() throws Exception{
		this.cn= cn;
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println(1);
		 cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/item", "root", "root");
		System.out.println(2);
		
	}
	@RequestMapping("studao")
	public Connection getCon() {
		return cn;
	}
	@RequestMapping("studentdao")
	public void setCon(Connection cn) {
		this.cn = cn;
	}

}
