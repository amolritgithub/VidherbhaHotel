package com.vidherbhahotel.VidherbhaHotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VidherbhaHotelApplication {

	public static void main(String[] args) {
		SpringApplication.run(VidherbhaHotelApplication.class, args);
	}

}
