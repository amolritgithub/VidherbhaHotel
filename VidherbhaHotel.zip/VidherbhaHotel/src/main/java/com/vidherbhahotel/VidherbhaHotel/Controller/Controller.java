package com.vidherbhahotel.VidherbhaHotel.Controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vidherbhahotel.VidherbhaHotel.X;
import com.vidherbhahotel.VidherbhaHotel.Menu.Menu;
import com.vidherbhahotel.VidherbhaHotel.Services.Services;


@RestController
public class Controller {
	@Autowired
	X x;
	@GetMapping("chkobj")
	public void loadIoc(){
		
		x.m2();
	}
	ArrayList<Menu>  menu = new ArrayList<Menu>();
	Services s = new Services();
	@GetMapping("hotelmenu")
	public ArrayList<Menu> fetchmenu() throws Exception{
		 menu = s.fetchmenu();
		return menu;
	}
	
	@RequestMapping("/hello")
	public String hello() {
		System.out.println("Welcome");
		return "Welcome to our Restaurant"+"\nOur Menu";
	}
	
	
	@GetMapping("/allmenu")
	public  ArrayList<Menu> getmenu() {
		System.out.println(menu);
		return menu;
	}
	


}
