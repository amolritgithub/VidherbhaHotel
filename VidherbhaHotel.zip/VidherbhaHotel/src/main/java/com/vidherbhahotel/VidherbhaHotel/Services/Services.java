package com.vidherbhahotel.VidherbhaHotel.Services;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.RestController;

import com.vidherbhahotel.VidherbhaHotel.Dao.Dao;
import com.vidherbhahotel.VidherbhaHotel.Menu.Menu;


@RestController
public class Services {
	public ArrayList<Menu> fetchmenu() throws Exception {
		Dao dao = new Dao();
		ArrayList<Menu> menu = dao.fetchmenu();
		ArrayList<Menu> menufiltered = new ArrayList<Menu>();
		for (Menu menu2 : menu) {
			if(menu2.getDescription().startsWith("n"));
			menufiltered.add(menu2);
		}
		return menufiltered;
		
	}

}
