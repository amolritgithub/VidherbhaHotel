package com.vidherbhahotel.VidherbhaHotel;

import org.springframework.stereotype.Component;

@Component
public class X {
	public X() {
		System.err.println("I am in Const");
	}
	public void m2(){
		System.err.println("Hello");
	}
	

}
